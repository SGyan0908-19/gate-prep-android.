"""Embedded local Flask server for the Android app."""
import os
import socket
import threading
from werkzeug.serving import make_server

_server = None
_thread = None
_lock = threading.Lock()

PREFERRED_PORTS = [5000] + list(range(5001, 5021)) + [0]  # 0 = let the OS pick any free port

def _bind_free_port():
    """Werkzeug calls sys.exit(1) if its port is taken, so find a free port ourselves first."""
    for port in PREFERRED_PORTS:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        try:
            s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            s.bind(("127.0.0.1", port))
            return s.getsockname()[1]
        except OSError:
            continue
        finally:
            s.close()
    raise RuntimeError("No free local port available")

def start_server(files_dir):
    """Never raises: returns "started:<port>" or "ERR:" + full traceback."""
    import traceback
    try:
        return _start(files_dir)
    except BaseException:  # includes SystemExit, which would otherwise hide the cause
        tb = traceback.format_exc()
        try:
            with open(os.path.join(files_dir, "startup-error.log"), "w") as f: f.write(tb)
        except Exception:
            pass
        return "ERR:" + tb

def _start(files_dir):
    global _server, _thread
    with _lock:
        if _server is not None:
            return "started:%d" % _server.server_port
        # Persist database inside Android's private app storage, not the APK bundle.
        os.environ["GATE_DB"] = os.path.join(files_dir, "gate.db")
        # Several legacy routes use relative static/ paths, so set a stable working directory.
        os.chdir(os.path.dirname(os.path.abspath(__file__)))
        os.environ["GATE_AI_API_KEY"] = os.environ.get("GATE_AI_API_KEY", "")
        import app as gate_app
        _port = _bind_free_port()
        _server = make_server("127.0.0.1", _port, gate_app.app, threaded=True)
        _thread = threading.Thread(target=_server.serve_forever, name="gate-flask", daemon=True)
        _thread.start()
        return "started:%d" % _port
