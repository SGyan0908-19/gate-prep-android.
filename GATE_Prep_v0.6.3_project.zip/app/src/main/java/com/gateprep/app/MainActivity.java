package com.gateprep.app;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.webkit.CookieManager;
import android.webkit.URLUtil;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import com.chaquo.python.PyObject;
import com.chaquo.python.Python;
import com.chaquo.python.android.AndroidPlatform;

public class MainActivity extends Activity {
    private static final int FILE_REQ = 4711;
    private String home = "http://127.0.0.1:5000/";
    private WebView webView;
    private LinearLayout root;
    private TextView status;
    private ValueCallback<Uri[]> fileCallback;
    private final Handler handler = new Handler(Looper.getMainLooper());

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        int navy = Color.parseColor("#0B1020");
        Window w = getWindow();
        w.setStatusBarColor(navy);
        w.setNavigationBarColor(navy);
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setBackgroundColor(navy);
        root.setPadding(48, 48, 48, 48);
        root.setOnApplyWindowInsetsListener((v, insets) -> {
            v.setPadding(v.getPaddingLeft(), insets.getSystemWindowInsetTop(), v.getPaddingRight(), insets.getSystemWindowInsetBottom());
            return insets;
        });
        status = new TextView(this);
        status.setText("GATE 2027 Prep\nPreparing your offline study database…");
        status.setTextColor(Color.parseColor("#EEF2FF"));
        status.setGravity(Gravity.CENTER);
        status.setTextSize(18);
        root.addView(status, new LinearLayout.LayoutParams(-1, -2));
        ProgressBar progress = new ProgressBar(this);
        root.addView(progress, new LinearLayout.LayoutParams(-2, -2));
        setContentView(root);

        new Thread(() -> {
            try {
                if (!Python.isStarted()) Python.start(new AndroidPlatform(this));
                PyObject module = Python.getInstance().getModule("android_server");
                String res = module.callAttr("start_server", getFilesDir().getAbsolutePath()).toString();
                if (res.startsWith("ERR:")) {
                    final String tb = res.substring(4);
                    handler.post(() -> showError("Could not start GATE Prep.\n\n" + tb));
                    return;
                }
                if (res.startsWith("started:")) home = "http://127.0.0.1:" + res.substring(8).trim() + "/";
                handler.post(this::showWebView);
            } catch (Throwable e) {
                String msg = e.getClass().getSimpleName() + ": " + e.getMessage();
                handler.post(() -> showError("Could not start GATE Prep.\n\n" + msg));
            }
        }, "gate-python-startup").start();
    }

    private void showError(String text) {
        root.removeAllViews();
        root.setGravity(Gravity.TOP);
        android.widget.ScrollView sv = new android.widget.ScrollView(this);
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setTextColor(Color.parseColor("#EEF2FF"));
        tv.setTextSize(12);
        tv.setTextIsSelectable(true);
        sv.addView(tv);
        root.addView(sv, new LinearLayout.LayoutParams(-1, -1));
    }

    private void showWebView() {
        root.removeAllViews();
        root.setPadding(0, root.getPaddingTop(), 0, root.getPaddingBottom());
        webView = new WebView(this);
        webView.setBackgroundColor(Color.parseColor("#0B1020"));
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(true); // needed for content:// URIs from the file picker
        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                Uri u = r.getUrl();
                if ("127.0.0.1".equals(u.getHost())) return false;
                try { startActivity(new Intent(Intent.ACTION_VIEW, u)); } catch (ActivityNotFoundException ignored) {}
                return true;
            }
        });
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams p) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = cb;
                try {
                    startActivityForResult(p.createIntent(), FILE_REQ);
                } catch (Exception e) {
                    fileCallback = null;
                    Toast.makeText(MainActivity.this, "No file picker available", Toast.LENGTH_LONG).show();
                    return false;
                }
                return true;
            }
        });
        webView.setDownloadListener((url, ua, cd, mime, len) -> saveDownload(url, cd, mime));
        root.addView(webView, new LinearLayout.LayoutParams(-1, -1));
        webView.loadUrl(home);
    }

    /** Downloads come from the local Flask server, so fetch them ourselves (no DownloadManager). */
    private void saveDownload(String url, String cd, String mime) {
        final String name = URLUtil.guessFileName(url, cd, mime);
        new Thread(() -> {
            try {
                java.net.HttpURLConnection c = (java.net.HttpURLConnection) new java.net.URL(url).openConnection();
                c.setConnectTimeout(10000);
                c.setReadTimeout(60000);
                String type = (mime == null || mime.isEmpty()) ? "application/octet-stream" : mime;
                java.io.OutputStream out;
                String where;
                if (Build.VERSION.SDK_INT >= 29) {
                    android.content.ContentValues v = new android.content.ContentValues();
                    v.put(android.provider.MediaStore.Downloads.DISPLAY_NAME, name);
                    v.put(android.provider.MediaStore.Downloads.MIME_TYPE, type);
                    v.put(android.provider.MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
                    Uri dest = getContentResolver().insert(android.provider.MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
                    out = getContentResolver().openOutputStream(dest);
                    where = "Downloads";
                } else {
                    java.io.File dir = getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS);
                    java.io.File f = new java.io.File(dir, name);
                    out = new java.io.FileOutputStream(f);
                    where = f.getAbsolutePath();
                }
                try (java.io.InputStream in = c.getInputStream(); java.io.OutputStream o = out) {
                    byte[] buf = new byte[16384];
                    int n;
                    while ((n = in.read(buf)) > 0) o.write(buf, 0, n);
                }
                final String msg = "Saved " + name + " to " + where;
                handler.post(() -> Toast.makeText(this, msg, Toast.LENGTH_LONG).show());
            } catch (Exception e) {
                final String msg = "Could not save file: " + e.getMessage();
                handler.post(() -> Toast.makeText(this, msg, Toast.LENGTH_LONG).show());
            }
        }, "gate-download").start();
    }

    @Override protected void onActivityResult(int req, int res, Intent data) {
        if (req == FILE_REQ && fileCallback != null) {
            fileCallback.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(res, data));
            fileCallback = null;
            return;
        }
        super.onActivityResult(req, res, data);
    }

    private long lastBack = 0;

    @Override public void onBackPressed() {
        if (webView == null) { super.onBackPressed(); return; }
        // The web app handles sheets, toolbar Back and tab history; it returns true if it consumed Back.
        webView.evaluateJavascript("window.__gateBack?window.__gateBack():false", v -> {
            if ("true".equals(v)) return;
            long now = System.currentTimeMillis();
            if (now - lastBack < 2000) { finish(); return; }
            lastBack = now;
            Toast.makeText(this, "Press Back again to exit", Toast.LENGTH_SHORT).show();
        });
    }

    @Override protected void onDestroy() {
        if (webView != null) webView.destroy();
        super.onDestroy();
    }
}
