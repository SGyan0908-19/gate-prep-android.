# GATE 2027 Prep v0.6.0 - redesign + icon + build fixes

**Status: NOT BUILT. No APK has been produced.** Build it on GitHub Actions.

## Changed
- Icon: navy adaptive launcher icon (G + cyan/blue cap + rising bars), all densities, round, monochrome, web icons; wired into AndroidManifest.
- UI (app/src/main/python/static/index.html): navy dark theme + light theme, 4 text sizes (Settings > Appearance), SVG nav icons, Home rings/streak/subject progress, Progress tab accuracy + strengths/weaknesses (from your own attempts, 3+ per topic).
- Android: themed loading screen, file picker (import / restore), downloads saved to Downloads, external links open in browser, back button closes sheets / goes Home / blocks accidental exit mid-test.
- Backend: backup and notes exports now send a filename. No other API/database change.
- Workflow: .github/workflows/main.yml uses the runner's built-in Android SDK (replaces android-actions/setup-android). Delete any old duplicate workflow files.

## v0.6.2 additions
- Back navigation: in-app history (Settings > Subjects > Back returns to Settings), sheets/forms close first, toolbar Back and Android Back behave the same, press Back twice on Home to exit.
- Live countdown (days/hours/min/sec, timezone-aware, never negative, ticks 1/sec only while visible).
- Startup errors now show the full Python traceback (and are written to startup-error.log).
- Window insets so content is not drawn under system bars on Android 15.

## v0.6.3 - startup crash root cause
- "PyException: SystemExit: 1" = Werkzeug calls sys.exit(1) when its port is already in use (reproduced). The app hard-coded port 5000. It now picks a free port (5000 first, then 5001-5020, then any) and the WebView loads that port.
- Added tzdata so the exam date/timezone can be saved on Android (no system tz database there).
- Workflow artifact is now named GATE-Prep-debug-APK.

## Not done
- Study reminders (need native notification code).
- Compiling MainActivity.java; device testing (file picker, downloads, Android 15 edge-to-edge).
