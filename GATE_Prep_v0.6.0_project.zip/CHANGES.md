# GATE 2027 Prep v0.6.0 - redesign + icon + build fixes

**Status: NOT BUILT. No APK has been produced.** Build it on GitHub Actions.

## Changed
- Icon: navy adaptive launcher icon (G + cyan/blue cap + rising bars), all densities, round, monochrome, web icons; wired into AndroidManifest.
- UI (app/src/main/python/static/index.html): navy dark theme + light theme, 4 text sizes (Settings > Appearance), SVG nav icons, Home rings/streak/subject progress, Progress tab accuracy + strengths/weaknesses (from your own attempts, 3+ per topic).
- Android: themed loading screen, file picker (import / restore), downloads saved to Downloads, external links open in browser, back button closes sheets / goes Home / blocks accidental exit mid-test.
- Backend: backup and notes exports now send a filename. No other API/database change.
- Workflow: .github/workflows/main.yml uses the runner's built-in Android SDK (replaces android-actions/setup-android). Delete any old duplicate workflow files.

## Not done
- Study reminders (need native notification code).
- Compiling MainActivity.java; device testing (file picker, downloads, Android 15 edge-to-edge).
