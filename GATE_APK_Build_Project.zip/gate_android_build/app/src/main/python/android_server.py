"""Embedded local Flask server for the Android app."""
import contextlib
import io
import os
import threading
import traceback

_server = None
_thread = None
_port = None
_lock = threading.Lock()


def _short_traceback():
    lines = traceback.format_exc().strip().splitlines()
    return "\n".join(lines[-8:])


def start_server(files_dir):
    """Start the local server on a free port and return that port number."""
    global _server, _thread, _port
    with _lock:
        if _server is not None:
            return _port
        try:
            # Persist database inside Android's private app storage, not the APK bundle.
            os.environ["GATE_DB"] = os.path.join(files_dir, "gate.db")
            # Several legacy routes use relative static/ paths, so set a stable working directory.
            os.chdir(os.path.dirname(os.path.abspath(__file__)))
            os.environ["GATE_AI_API_KEY"] = os.environ.get("GATE_AI_API_KEY", "")
            import app as gate_app
            from werkzeug.serving import make_server

            # Port 0 = let Android pick any free port (a fixed port 5000 can be taken).
            # werkzeug calls sys.exit(1) on bind errors after printing the reason to
            # stderr, so capture that text and report it instead of a bare "SystemExit: 1".
            buf = io.StringIO()
            try:
                with contextlib.redirect_stderr(buf):
                    server = make_server("127.0.0.1", 0, gate_app.app, threaded=True)
            except SystemExit:
                raise RuntimeError(
                    "Could not open local server port: " + (buf.getvalue().strip() or "unknown error")
                )
            port = server.socket.getsockname()[1]
            thread = threading.Thread(target=server.serve_forever, name="gate-flask", daemon=True)
            thread.start()
            _server, _thread, _port = server, thread, port
            return port
        except BaseException:
            raise RuntimeError(_short_traceback())
