# GATE Prep Android - build fixes

**Status: NOT BUILT.** No APK has been produced. The sandbox used for this work
could not reach Google/Maven/Gradle/Chaquopy download servers, so Gradle could not
run. Everything below was checked by reading code and docs, not by compiling.

## What was found

| # | Problem | Where | Confidence |
|---|---------|-------|------------|
| 1 | `android-actions/setup-android@v3` step fails with sdkmanager exit code 1 | `.github/workflows/main.yml` | Step is the one you reported. Exact sdkmanager error text could not be read (Actions logs were not accessible). The step is unnecessary: GitHub Ubuntu runners already include the Android SDK. |
| 2 | `python { ... }` is a top-level block. Chaquopy 16 expects `chaquopy { defaultConfig { ... } }` (or the old Groovy-only block inside `android.defaultConfig`) | `app/build.gradle` | High (Chaquopy docs + changelog). Would fail right after the SDK step. |
| 3 | No `abiFilters`. Chaquopy requires them | `app/build.gradle` | High (Chaquopy docs). |
| 4 | `FAIL_ON_PROJECT_REPOS` can abort the build if a plugin adds a repository | `settings.gradle` | Precaution, not a confirmed failure. |
| 5 | Repo root has stray files: `main.yml` (a second copy of the workflow) and `github/workflows/build.yml` (no leading dot, so never runs, and its indentation is broken YAML). Only `.github/workflows/main.yml` runs. | repo root | Certain. Not touched; suggest you delete them. |
| 6 | Loose `app.py`, `tracker.py`, `scoring.py`, `android_server.py`, `index.html`, `sw.js`, `manifest.json`, `MainActivity.java`, `AndroidManifest.xml` in the repo root are byte-identical to the ZIP contents. The build uses only the ZIP. | repo root | Certain. |

## What was changed

1. `.github/workflows/main.yml` (replacement): removed `setup-android`; uses the runner's
   SDK, accepts licenses, installs API 35 / build-tools 35.0.0 only if missing; falls back
   to downloading cmdline-tools; prints the SDK layout; saves `gradle-build.log`; writes the
   key error lines into the run summary; uploads logs on failure.
2. `app/build.gradle`: new `chaquopy {}` block (same Python 3.10, same `flask==3.1.1`),
   plus `ndk { abiFilters 'arm64-v8a', 'armeabi-v7a', 'x86_64' }`.
3. `settings.gradle`: `PREFER_SETTINGS`, plus Chaquopy's Maven repo as a last-resort fallback.
4. `.github/workflows/build-apk.yml` inside the ZIP: same fixes, for building from the unzipped project.

## Not changed

All app code: `app.py`, `tracker.py`, `scoring.py`, `android_server.py`, `index.html`,
`sw.js`, `manifest.json`, icons, `MainActivity.java`, `AndroidManifest.xml`. No questions,
data or features were added or removed.

## Checked offline

- YAML parses; `bash -n` passes for every `run:` script.
- All Python files compile.
- Gradle parses `settings.gradle` and root `build.gradle`; it stops at plugin download (no network).

## Still unverified (needs a real build)

- Java compile of `MainActivity.java`, Chaquopy pip install of Flask for each ABI, APK packaging.
- Whether the app runs on a device: Flask server start, WebView load, SQLite persistence,
  behavior when Android suspends the process. The README already notes this was never run.
- The AI assistant feature needs an API key; there is no in-app way to set one yet.
